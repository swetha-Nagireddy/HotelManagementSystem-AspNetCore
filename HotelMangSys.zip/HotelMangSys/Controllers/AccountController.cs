﻿using HotelMangSys.Models;
using HotelMangSys.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using HotelMangSys.Models.ViewModels;
using HotelMangSys.Models.ViewModels;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

namespace HotelMangSys.Controllers
{
    public class AccountController : Controller
    {
        private readonly ILogger<AccountController> _logger;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly JwtTokenService _jwtTokenService;
        private readonly ApplicationDbContext _context;

        public AccountController(UserManager<ApplicationUser> userManager,
                                  SignInManager<ApplicationUser> signInManager,
                                  JwtTokenService jwtTokenService,
                                  ILogger<AccountController> logger,
                                  ApplicationDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _jwtTokenService = jwtTokenService;
            _logger = logger;
            _context = context;
        }

        // Register Page
        public IActionResult Register()
        {
            return View();
        }

        //[HttpPost]
        //public async Task<IActionResult> Register(RegisterViewModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var user = new ApplicationUser { UserName = model.Username, FullName = model.FullName, Address = model.Address, Email = model.Email, PhoneNumber = model.PhoneNumber };
        //        var result = await _userManager.CreateAsync(user, model.Password);

        //        if (result.Succeeded)
        //        {
        //            TempData["Success"] = "User registered successfully!";
        //            _logger.LogInformation("User created a new account with password.");
        //            await _signInManager.SignInAsync(user, isPersistent: false);
        //            return RedirectToAction("Login", "Account");

        //        }

        //        foreach (var error in result.Errors)
        //        {
        //            ModelState.AddModelError(string.Empty, error.Description);
        //        }
        //    }
        //    return View(model);
        //}

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser
                {
                    UserName = model.Username,
                    Email = model.Email,
                    FullName = model.FullName,
                    Address = model.Address,
                    PhoneNumber = model.PhoneNumber
                };

                var result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    TempData["Success"] = "User registered successfully!";
                    return RedirectToAction("Register");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            return View(model);
        }


        // Login Page

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByNameAsync(model.Username);

                if (user != null)
                {
                    var result = await _signInManager.PasswordSignInAsync(user, model.Password, false, false);

                    if (result.Succeeded)
                    {
                        _logger.LogInformation("User logged in.");

                        // Save the UserId in a cookie
                        var userId = user.Id;
                        var cookieOptions = new CookieOptions
                        {
                            HttpOnly = true, // Makes the cookie accessible only through HTTP requests
                            Secure = true,   // Ensures the cookie is sent only over HTTPS
                            SameSite = SameSiteMode.Strict, // Helps mitigate CSRF attacks
                            Expires = DateTime.Now.AddDays(7) // Cookie expires in 7 days
                        };
                        Response.Cookies.Append("UserId", userId, cookieOptions);

                        var token = _jwtTokenService.GenerateJwtToken(user.UserName);
                        return Json(new { token }); // ✅ JSON response
                    }
                }

                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            }
            _logger.LogWarning("Invalid login attempt.");

            return BadRequest("Invalid login.");
        }

        [HttpGet]
        public async Task<IActionResult> UserDetails()
        {
            if (Request.Cookies.TryGetValue("UserId", out var userId))
            {
                var user = await _userManager.FindByIdAsync(userId);
                if (user != null)
                {
                    // Pass the user directly to the view
                    return View(user);
                }
            }

            // Redirect to login if user not found or not logged in
            return RedirectToAction("Login", "Account");
        }

        // GET: /Account/UpdateProfile
        [HttpGet]
        public async Task<IActionResult> UpdateProfile()
        {
            if (Request.Cookies.TryGetValue("UserId", out var userId))
            {
                var user = await _userManager.FindByIdAsync(userId);
                if (user != null)
                {
                    return View(user);
                }
            }

            return RedirectToAction("Login", "Account");
        }

        // POST: /Account/UpdateProfile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateProfile(ApplicationUser model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.FindByIdAsync(model.Id);
                if (user != null)
                {
                    user.FullName = model.FullName;
                    user.Address = model.Address;
                    user.Email = model.Email;
                    user.PhoneNumber = model.PhoneNumber;

                    var result = await _userManager.UpdateAsync(user);
                    if (result.Succeeded)
                    {
                        TempData["SuccessMessage"] = "Profile updated successfully!";
                        return RedirectToAction("UpdateProfile");
                    }

                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }

            return View(model);
        }
        // Logout
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            _logger.LogInformation("User logged out.");
            return RedirectToAction("Login");
        }



    }
}
